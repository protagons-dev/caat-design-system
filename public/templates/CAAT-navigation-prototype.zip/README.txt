CAAT Pension Plan — Navigation Usability Prototype
==================================================

WHAT THIS IS
A self-contained, offline HTML prototype of the proposed CAAT navigation,
built from the CAAT Design System for the moderated navigation usability test.
It replaces the Figma prototype: participants click through a real, styled
website instead of a click-through mockup.

HOW TO OPEN  (no internet, no install, no server)
1. Unzip this folder anywhere on your computer.
2. Double-click "index.html". It opens in your default browser.
Everything — fonts, styles, icons, scripts, images — is bundled inside the
"assets" folder and loads from disk. No internet connection is required.
Tested in Chrome, Edge and Firefox, on Windows and Mac.

(If your browser is locked down and blocks local files, you can instead run a
tiny local server from this folder:  python -m http.server 8091
then open  http://localhost:8091  — but double-clicking index.html normally
just works.)

WHAT'S INSIDE
  index.html ................. site home page — start each task here
  members.html, life-in-retirement.html, estimate-your-pension.html, ...
                              ~60 navigable pages covering the full proposed IA
  _facilitator-guide.html .... moderator's task -> success-path cheat sheet
                              (open this yourself; it is NOT linked from the site)
  assets/ .................... styles, scripts, fonts, images  (do not delete/move)

NOTES FOR THE TEST
- Findability prototype: every menu item leads to a real page, so participants
  never hit a dead end. Deeper page content is representative, not final copy.
- The "DBprime / DBplus" plan-design tool (on Estimate-your-pension and
  Understand-inflation-protection) is interactive; its routing is illustrative
  for the test, not a real plan-design determination.
- IA follows the "Prototype copy" table exactly. Top-level (L1) nav is:
  Pension Solutions, Members, Employers, Investments, About us. Members holds
  the four member sections (Navigate your pension, Get ready to retire, Life
  in retirement, Learning Centre) and their L3-L5 pages. Pension Solutions has
  no children listed in the doc, so it is a top-level landing page.

Built 2026-07-15 from the CAAT Design System. Prototype only — not a live site.
